
#### The Mayor of South Bend, James Mueller has reached out to our Data Science Team to prepare an interactive dashboard and presentation using South Bend Civic data. We will be utilizing data sets from the City of South Bend’s Open Data Portal via Github. 


## The data set includes information below: 
#### 311 Calls, 
#### City Council Districts, 
#### Park & Public Facilities, 
#### Abandoned Properties.


Please explore each tab to find out about each area.

This Shiny App has been produced by **Austin Kim, Detong Song , Shahriar Nasir and Zhuoyu Qian** Section West, Group 3, Data Science Department – Notre Dame University 2023
